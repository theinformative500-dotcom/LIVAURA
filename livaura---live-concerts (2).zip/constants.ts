import { Concert, Genre } from './types';
import { IconProps } from './types';

export const SIDEBAR_ICONS: { name: string; icon: IconProps['path'], page: string }[] = [
    { name: 'Home', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6', page: 'home' },
    { name: 'Explore', icon: 'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z', page: 'search' },
    { name: 'Downloads', icon: 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4', page: 'downloads' },
    { name: 'History', icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z', page: 'history' },
];

// FIX: Export MOCK_CONCERTS to be used in other components.
export const MOCK_CONCERTS: Concert[] = [
  { id: 'c1', title: 'Live at Wembley', artist: 'Sidhu Moose Wala', genre: 'Rock', imageUrl: 'https://i.imgur.com/f0y4gqG.jpg', heroUrl: 'https://i.imgur.com/f0y4gqG.jpg', description: 'A spectacular live performance by the Punjabi music icon, Sidhu Moose Wala.' },
  { id: 'c2', title: 'The Formation World Tour', artist: 'Beyoncé', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/beyonce/400/600', heroUrl: 'https://picsum.photos/seed/beyonce_hero/1280/720', description: 'A visually stunning and powerful performance from Beyoncé’s iconic world tour.' },
  { id: 'c3', title: 'Alive 2007', artist: 'Daft Punk', genre: 'Electronic', imageUrl: 'https://picsum.photos/seed/daftpunk/400/600', heroUrl: 'https://picsum.photos/seed/daftpunk_hero/1280/720', description: 'The groundbreaking electronic duo in their most famous live set.' },
  { id: 'c4', title: 'Live from the Royal Albert Hall', artist: 'Adele', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/adele/400/600', heroUrl: 'https://picsum.photos/seed/adele_hero/1280/720', description: 'An intimate and powerful performance from one of the greatest voices of our time.' },
  { id: 'c5', title: 'S&M', artist: 'Metallica', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/metallica/400/600', heroUrl: 'https://picsum.photos/seed/metallica_hero/1280/720', description: 'The iconic collaboration between heavy metal legends Metallica and the San Francisco Symphony.' },
  { id: 'c6', title: 'Coachella 2018', artist: 'Odesza', genre: 'Electronic', imageUrl: 'https://picsum.photos/seed/odesza/400/600', heroUrl: 'https://picsum.photos/seed/odesza_hero/1280/720', description: 'A cinematic and breathtaking live show from the electronic music titans.' },
  { id: 'c7', title: 'Live in Texas', artist: 'Linkin Park', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/linkinpark/400/600', heroUrl: 'https://picsum.photos/seed/linkinpark_hero/1280/720', description: 'A raw and energetic performance from the height of their career.' },
  { id: 'c8', title: 'Reputation Stadium Tour', artist: 'Taylor Swift', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/taylor/400/600', heroUrl: 'https://picsum.photos/seed/taylor_hero/1280/720', description: 'The record-breaking stadium tour with spectacular visuals and production.' },
  { id: 'c9', title: 'Live at Red Rocks', artist: 'Flume', genre: 'Electronic', imageUrl: 'https://picsum.photos/seed/flume/400/600', heroUrl: 'https://picsum.photos/seed/flume_hero/1280/720', description: 'An immersive audio-visual experience at the legendary Red Rocks Amphitheatre.' },
  { id: 'c10', title: 'The Wall – Live in Berlin', artist: 'Roger Waters', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/rogerwaters/400/600', heroUrl: 'https://picsum.photos/seed/rogerwaters_hero/1280/720', description: 'A monumental performance of Pink Floyd\'s The Wall to commemorate the fall of the Berlin Wall.' },
  { id: 'c11', title: 'Homecoming', artist: 'Beyoncé', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/homecoming/400/600', heroUrl: 'https://picsum.photos/seed/homecoming_hero/1280/720', description: 'A deep dive into the iconic 2018 Coachella performance that celebrated Black culture.' },
  { id: 'c12', title: 'Stop Making Sense', artist: 'Talking Heads', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/talkingheads/400/600', heroUrl: 'https://picsum.photos/seed/talkingheads_hero/1280/720', description: 'Hailed as one of the greatest concert films of all time, a masterpiece of performance and cinema.' },
  { id: 'c13', title: 'Live at Glastonbury', artist: 'Arctic Monkeys', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/arcticmonkeys/400/600', heroUrl: 'https://picsum.photos/seed/arcticmonkeys_hero/1280/720', description: 'A legendary headline set from the UK\'s biggest rock band.' },
  { id: 'c14', title: 'Royal Albert Hall', artist: 'The Killers', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/killers/400/600', heroUrl: 'https://picsum.photos/seed/killers_hero/1280/720', description: 'The Killers deliver an electrifying performance at a world-famous venue.' },
  { id: 'c15', title: 'From the Basement', artist: 'Radiohead', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/radiohead/400/600', heroUrl: 'https://picsum.photos/seed/radiohead_hero/1280/720', description: 'An intimate and intense live studio session with Radiohead.' },
  { id: 'c16', title: 'MTV Unplugged in New York', artist: 'Nirvana', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/nirvana/400/600', heroUrl: 'https://picsum.photos/seed/nirvana_hero/1280/720', description: 'One of the most iconic and haunting acoustic performances ever recorded.' },
  { id: 'c17', title: 'Live at Wembley Stadium', artist: 'Foo Fighters', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/foofighters/400/600', heroUrl: 'https://picsum.photos/seed/foofighters_hero/1280/720', description: 'Two sold-out nights of pure rock energy from the Foo Fighters.' },
  { id: 'c18', title: 'Zoo TV Tour', artist: 'U2', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/u2/400/600', heroUrl: 'https://picsum.photos/seed/u2_hero/1280/720', description: 'A groundbreaking tour that redefined the live rock show with multimedia saturation.' },
  { id: 'c19', title: 'The Song Remains the Same', artist: 'Led Zeppelin', genre: 'Rock', imageUrl: 'https://picsum.photos/seed/ledzeppelin/400/600', heroUrl: 'https://picsum.photos/seed/ledzeppelin_hero/1280/720', description: 'The legendary concert film from Led Zeppelin\'s 1973 tour.' },
  { id: 'c20', title: 'Live in Bucharest', artist: 'Michael Jackson', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/mj/400/600', heroUrl: 'https://picsum.photos/seed/mj_hero/1280/720', description: 'The King of Pop at the height of his fame on the Dangerous World Tour.' },
  { id: 'c21', title: 'The Monster Ball Tour', artist: 'Lady Gaga', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/gaga/400/600', heroUrl: 'https://picsum.photos/seed/gaga_hero/1280/720', description: 'A theatrical and artistic spectacle from one of pop\'s most creative forces.' },
  { id: 'c22', title: 'FutureSex/LoveShow', artist: 'Justin Timberlake', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/jt/400/600', heroUrl: 'https://picsum.photos/seed/jt_hero/1280/720', description: 'JT\'s critically acclaimed tour featuring slick choreography and stunning visuals.' },
  { id: 'c23', title: 'Future Nostalgia Tour', artist: 'Dua Lipa', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/dualipa/400/600', heroUrl: 'https://picsum.photos/seed/dualipa_hero/1280/720', description: 'A disco-pop dream with non-stop dancing and vibrant aesthetics.' },
  { id: 'c24', title: 'Love On Tour', artist: 'Harry Styles', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/harry/400/600', heroUrl: 'https://picsum.photos/seed/harry_hero/1280/720', description: 'A celebration of love and music with global superstar Harry Styles.' },
  { id: 'c25', title: 'Where Do We Go? The Livestream', artist: 'Billie Eilish', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/billie/400/600', heroUrl: 'https://picsum.photos/seed/billie_hero/1280/720', description: 'An innovative and immersive livestream concert experience.' },
  { id: 'c26', title: 'The Blond Ambition Tour', artist: 'Madonna', genre: 'Pop', imageUrl: 'https://picsum.photos/seed/madonna/400/600', heroUrl: 'https://picsum.photos/seed/madonna_hero/1280/720', description: 'The iconic and controversial tour that set a new standard for pop performances.' },
  { id: 'c27', title: 'Don\'t Think', artist: 'The Chemical Brothers', genre: 'Electronic', imageUrl: 'https://picsum.photos/seed/chemicalbros/400/600', heroUrl: 'https://picsum.photos/seed/chemicalbros_hero/1280/720', description: 'A psychedelic and immersive concert film that puts you in the heart of the show.' },
  { id: 'c28', title: 'Live at Red Rocks', artist: 'Skrillex', genre: 'Electronic', imageUrl: 'https://picsum.photos/seed/skrillex/400/600', heroUrl: 'https://picsum.photos/seed/skrillex_hero/1280/720', description: 'A bass-heavy, visually stunning performance from the EDM pioneer.' },
  { id: 'c29', title: 'Worlds Live', artist: 'Porter Robinson', genre: 'Electronic', imageUrl: 'https://picsum.photos/seed/porter/400/600', heroUrl: 'https://picsum.photos/seed/porter_hero/1280/720', description: 'An emotional and story-driven electronic music show.' },
  { id: 'c30', title: 'Coachella 2019', artist: 'Aphex Twin', genre: 'Electronic', imageUrl: 'https://picsum.photos/seed/aphex/400/600', heroUrl: 'https://picsum.photos/seed/aphex_hero/1280/720', description: 'A mind-bending and experimental set from the electronic music legend.' },
  { id: 'c31', title: 'Meowingtons Hax Tour', artist: 'deadmau5', genre: 'Electronic', imageUrl: 'https://picsum.photos/seed/deadmau5/400/600', heroUrl: 'https://picsum.photos/seed/deadmau5_hero/1280/720', description: 'The iconic cube, the mau5head, and a catalog of electronic anthems.' },
  { id: 'c32', title: 'One Last Tour', artist: 'Swedish House Mafia', genre: 'Electronic', imageUrl: 'https://picsum.photos/seed/shm/400/600', heroUrl: 'https://picsum.photos/seed/shm_hero/1280/720', description: 'The emotional farewell tour from the progressive house supergroup.' },
];

export const FEATURED_CONCERT: Concert = MOCK_CONCERTS[1];

export const MOCK_GENRES: Genre[] = [
  {
    id: 'g1',
    name: 'Trending Now',
    concerts: MOCK_CONCERTS.filter(c => c.genre === 'Pop'),
  },
  {
    id: 'g2',
    name: 'Punjabi Singer',
    concerts: MOCK_CONCERTS.filter(c => c.genre === 'Rock'),
  },
  {
    id: 'g3',
    name: 'Pop Stars/English',
    concerts: MOCK_CONCERTS.filter(c => c.genre === 'Electronic'),
  },
   {
    id: 'g4',
    name: 'K-Pop',
    concerts: [...MOCK_CONCERTS].reverse(),
  },
  {
    id: 'g5',
    name: 'Pakistani: Coke Studio, Sufi, Pop',
    concerts: MOCK_CONCERTS.filter(c => ['c1', 'c3', 'c12', 'c10', 'c16', 'c20', 'c26'].includes(c.id)),
  },
  {
    id: 'g6',
    name: 'Hindi/Bollywood',
    concerts: MOCK_CONCERTS.filter(c => ['c2', 'c4', 'c8', 'c11', 'c21', 'c23', 'c25', 'c26'].includes(c.id)),
  },
  {
    id: 'g7',
    name: 'Arabic',
    concerts: MOCK_CONCERTS.filter(c => ['c3', 'c6', 'c8', 'c9', 'c21', 'c27', 'c29'].includes(c.id)),
  },
];