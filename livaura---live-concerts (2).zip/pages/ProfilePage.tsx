import React, { useContext, useRef } from 'react';
import { UserContext } from '../App';
import Icon from '../components/Icon';

const ProfilePage: React.FC = () => {
  const userContext = useContext(UserContext);
  if (!userContext) {
    throw new Error('ProfilePage must be used within a UserProvider');
  }
  const { profileImage, setProfileImage } = userContext;
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const MAX_FILE_SIZE_MB = 2;
      const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
      const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

      if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
        alert('Invalid file type. Please select a JPEG, PNG, GIF, or WebP image.');
        // Reset the file input so the user can select a different file
        if(fileInputRef.current) {
          fileInputRef.current.value = "";
        }
        return;
      }

      if (file.size > MAX_FILE_SIZE_BYTES) {
        alert(`File is too large. Please select an image smaller than ${MAX_FILE_SIZE_MB}MB.`);
        if(fileInputRef.current) {
          fileInputRef.current.value = "";
        }
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="p-4 sm:p-8 lg:px-12 text-white flex flex-col items-center pt-10 sm:pt-20 animate-fade-in">
      <div className="relative group">
        <div className="w-32 h-32 rounded-full bg-teal-500 overflow-hidden mb-6 border-4 border-gray-700 transition-all duration-300 group-hover:border-red-500/50">
          <img src={profileImage} alt="User Profile" className="w-full h-full object-cover" />
        </div>
        <button
          onClick={handleImageClick}
          className="absolute inset-0 w-32 h-32 rounded-full flex flex-col items-center justify-center bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 cursor-pointer"
          aria-label="Change profile picture"
        >
          <Icon path="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" className="h-8 w-8 text-white mb-1" />
          <span className="text-xs font-bold">Change Photo</span>
        </button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*"
          className="hidden"
        />
      </div>

      <h1 className="text-4xl font-bold mb-2">Alex Doe</h1>
      <p className="text-gray-400 mb-8">alex.doe@example.com</p>
      
      <div className="w-full max-w-md">
        <h2 className="text-2xl font-semibold mb-4 border-b border-gray-700 pb-2">Account Settings</h2>
        <div className="space-y-4">
          <button className="w-full text-left p-3 bg-gray-800/50 hover:bg-gray-800 rounded-lg transition-colors">
            Manage Subscription
          </button>
          <button className="w-full text-left p-3 bg-gray-800/50 hover:bg-gray-800 rounded-lg transition-colors">
            Edit Profile
          </button>
          <button className="w-full text-left p-3 bg-gray-800/50 hover:bg-gray-800 rounded-lg transition-colors">
            Change Password
          </button>
          <button className="w-full text-left p-3 bg-red-600/80 hover:bg-red-600 rounded-lg transition-colors font-bold mt-8">
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;