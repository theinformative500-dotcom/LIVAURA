import React from 'react';
import Icon from '../components/Icon';

const DownloadsPage: React.FC = () => {
  return (
    <div className="p-4 sm:p-8 lg:px-12 text-center flex flex-col items-center justify-center h-full">
      <Icon path="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" className="h-24 w-24 text-gray-600 mb-6" />
      <h1 className="text-3xl font-bold mb-4">Your Downloads</h1>
      <p className="text-gray-400 max-w-md">
        You haven't downloaded any concerts yet. Concerts you download will appear here for offline viewing.
      </p>
    </div>
  );
};

export default DownloadsPage;
