import React, { useState, useMemo } from 'react';
import Icon from '../components/Icon';
import { MOCK_CONCERTS } from '../constants';
import { Concert } from '../types';

const SearchPage: React.FC = () => {
  const [query, setQuery] = useState('');

  const topArtists = useMemo(() => {
    const artistMap = new Map<string, Concert>();
    MOCK_CONCERTS.forEach(concert => {
      if (!artistMap.has(concert.artist)) {
        artistMap.set(concert.artist, concert);
      }
    });
    return Array.from(artistMap.values());
  }, []);
  
  const filteredArtists = useMemo(() => {
    if (query.length < 1) {
      return topArtists;
    }
    const lowerCaseQuery = query.toLowerCase();
    return topArtists.filter(artist => 
      artist.artist.toLowerCase().includes(lowerCaseQuery)
    );
  }, [query, topArtists]);

  return (
    <div className="p-4 sm:p-8 lg:px-12">
      {/* Search Input */}
      <div className="relative w-full max-w-2xl mx-auto mb-12">
        <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
          <Icon path="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" className="h-6 w-6 text-gray-400" />
        </div>
        <input
          type="search"
          placeholder="Search artists..."
          className="w-full bg-gray-900/70 border border-gray-800 focus:border-red-600/50 focus:ring-red-600/50 text-white rounded-full py-3 pl-16 pr-6 text-lg transition-colors"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
        />
      </div>

      {/* Artists Grid */}
      <div>
        <h2 className="text-2xl font-bold mb-6 whitespace-nowrap">
          {query ? 'Search Results' : 'Trending Now'}
        </h2>
        {filteredArtists.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-6 gap-y-8">
            {filteredArtists.map((artist, index) => (
               <div key={artist.artist} className="group flex flex-col items-center text-center cursor-pointer">
                <div 
                  data-ignore-outside-click="true"
                  className="relative w-40 h-40 sm:w-48 sm:h-48 flex-shrink-0 rounded-full overflow-hidden transition-all duration-300 ease-in-out transform group-hover:scale-105 group-hover:shadow-2xl group-hover:shadow-red-600/30"
                >
                  <img src={artist.imageUrl} alt={artist.artist} className="w-full h-full object-cover" loading="lazy" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center p-2">
                    <Icon path="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" className="h-10 w-10 text-white"/>
                  </div>
                </div>
                <h3 className="text-white font-bold text-sm mt-3 w-full truncate">{index + 1}. {artist.artist}</h3>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-400 text-center py-10">No artists found for "{query}"</p>
        )}
      </div>
    </div>
  );
};

export default SearchPage;