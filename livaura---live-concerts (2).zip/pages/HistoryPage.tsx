import React from 'react';
import Icon from '../components/Icon';

const HistoryPage: React.FC = () => {
  return (
    <div className="p-4 sm:p-8 lg:px-12 text-center flex flex-col items-center justify-center h-full">
      <Icon path="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" className="h-24 w-24 text-gray-600 mb-6" />
      <h1 className="text-3xl font-bold mb-4">Viewing History</h1>
      <p className="text-gray-400 max-w-md">
        Concerts you've watched will appear here, making it easy to find them again.
      </p>
    </div>
  );
};

export default HistoryPage;
