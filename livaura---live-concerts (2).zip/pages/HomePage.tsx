import React from 'react';
import Hero from '../components/Hero';
import ContentRow from '../components/ContentRow';
import { FEATURED_CONCERT, MOCK_GENRES } from '../constants';

const HomePage: React.FC = () => {
  return (
    <div>
      <Hero concert={FEATURED_CONCERT} />
      <div className="relative z-10 p-4 sm:p-8 lg:px-12 pt-2 -mt-16">
        {MOCK_GENRES.map(genre => (
          <ContentRow 
            key={genre.id} 
            title={genre.name} 
            concerts={genre.concerts} 
            showRank={genre.name === 'Trending Now'}
          />
        ))}
      </div>
    </div>
  );
};

export default HomePage;