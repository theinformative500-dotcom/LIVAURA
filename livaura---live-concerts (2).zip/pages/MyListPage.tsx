import React, { useContext } from 'react';
import Icon from '../components/Icon';
import { MyListContext } from '../App';
import { MOCK_CONCERTS } from '../constants';
import Thumbnail from '../components/Thumbnail';

const MyListPage: React.FC = () => {
  const context = useContext(MyListContext);
  if (!context) {
    throw new Error('MyListPage must be used within a MyListProvider');
  }
  const { myList } = context;

  const listedConcerts = MOCK_CONCERTS.filter(concert => myList.includes(concert.id));

  if (listedConcerts.length === 0) {
    return (
       <div className="p-4 sm:p-8 lg:px-12 text-center flex flex-col items-center justify-center h-full">
        <Icon path="M12 4v16m8-8H4" className="h-24 w-24 text-gray-600 mb-6" />
        <h1 className="text-3xl font-bold mb-4">Your List is Empty</h1>
        <p className="text-gray-400 max-w-md">
          Add concerts to your list by clicking the plus icon.
        </p>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-8 lg:px-12 animate-fade-in">
      <h1 className="text-3xl font-bold mb-8">My List</h1>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-6 gap-y-8">
        {listedConcerts.map(concert => (
          <div key={concert.id} className="flex flex-col items-center text-center">
            <Thumbnail concert={concert} />
            <h3 className="text-white font-bold text-sm mt-3 w-48 truncate">{concert.artist}</h3>
            <p className="text-gray-400 text-xs w-48 truncate">{concert.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyListPage;