// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDUjZdRK3uyMYzS8pPdyj4x_WgpVIPolN4",
  authDomain: "livaura-48487.firebaseapp.com",
  databaseURL: "https://livaura-48487-default-rtdb.firebaseio.com",
  projectId: "livaura-48487",
  storageBucket: "livaura-48487.appspot.com",
  messagingSenderId: "241697673739",
  appId: "1:241697673739:web:67d062e9aeff39ddd1ad0e",
  measurementId: "G-FJ0T3LGY7Q"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

export { app, analytics };
