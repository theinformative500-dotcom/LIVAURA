export interface Concert {
  id: string;
  title: string;
  artist: string;
  genre: string;
  imageUrl: string;
  heroUrl: string;
  description: string;
}

export interface Genre {
  id: string;
  name: string;
  concerts: Concert[];
}

export interface SearchResults {
  artists: Concert[];
  concerts: Concert[];
}

// FIX: Added WatchHistory type for tracking user's watch progress.
export interface WatchHistory {
  [concertId: string]: number;
}

export interface Notification {
  id: string;
  type: 'new_release' | 'recommendation' | 'live_event';
  message: string;
  artist: string;
  timestamp: string;
  read: boolean;
}

export interface IconProps {
  path: string;
  className?: string;
}
