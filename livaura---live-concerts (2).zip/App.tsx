import React, { useState, useRef, useEffect, createContext } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import SearchPage from './pages/SearchPage';
import DownloadsPage from './pages/DownloadsPage';
import HistoryPage from './pages/HistoryPage';
import MyListPage from './pages/MyListPage';
import ProfilePage from './pages/ProfilePage';
import { WatchHistory } from './types';

interface MyListContextType {
  myList: string[];
  addToMyList: (id: string) => void;
  removeFromMyList: (id: string) => void;
  isInMyList: (id: string) => boolean;
}

export const MyListContext = createContext<MyListContextType | undefined>(undefined);

interface UserContextType {
  profileImage: string;
  setProfileImage: (image: string) => void;
}

export const UserContext = createContext<UserContextType | undefined>(undefined);

interface WatchHistoryContextType {
  watchHistory: WatchHistory;
  updateWatchProgress: (concertId: string, progress: number) => void;
}

export const WatchHistoryContext = createContext<WatchHistoryContextType | undefined>(undefined);


const App: React.FC = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(window.innerWidth > 1024);
  const [currentPage, setCurrentPage] = useState('home');
  const sidebarRef = useRef<HTMLElement>(null);
  const [myList, setMyList] = useState<string[]>(['c2', 'c8', 'c23']);
  const [profileImage, setProfileImage] = useState('https://i.imgur.com/3YQhW1x.png');
  const [watchHistory, setWatchHistory] = useState<WatchHistory>({
    'c3': 0.5,
    'c5': 0.25,
    'c7': 0.8,
    'c1': 1,
  });

  const updateWatchProgress = (concertId: string, progress: number) => {
    setWatchHistory(prev => ({ ...prev, [concertId]: progress }));
  };

  const addToMyList = (id: string) => {
    setMyList(prevList => [...prevList, id]);
  };

  const removeFromMyList = (id: string) => {
    setMyList(prevList => prevList.filter(concertId => concertId !== id));
  };

  const isInMyList = (id: string) => {
    return myList.includes(id);
  };

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const navigateTo = (page: string) => {
    setCurrentPage(page);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        sidebarRef.current &&
        !sidebarRef.current.contains(event.target as Node) &&
        (event.target as HTMLElement).getAttribute('data-ignore-outside-click') !== 'true'
      ) {
        setSidebarOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'search':
        return <SearchPage />;
      case 'downloads':
        return <DownloadsPage />;
      case 'history':
        return <HistoryPage />;
      case 'mylist':
        return <MyListPage />;
      case 'profile':
        return <ProfilePage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <UserContext.Provider value={{ profileImage, setProfileImage }}>
      <MyListContext.Provider value={{ myList, addToMyList, removeFromMyList, isInMyList }}>
        <WatchHistoryContext.Provider value={{ watchHistory, updateWatchProgress }}>
          <div className="bg-black text-white min-h-screen">
            <Sidebar
              ref={sidebarRef}
              isOpen={isSidebarOpen}
              toggleSidebar={toggleSidebar}
              navigateTo={navigateTo}
            />
            <Header
              isOpen={isSidebarOpen}
              onSearchClick={() => navigateTo('search')}
              navigateTo={navigateTo}
              onHomeClick={() => navigateTo('home')}
              showBackButton={currentPage !== 'home'}
              onBackClick={() => navigateTo('home')}
            />
            <main
              className={`transition-all duration-300 ${
                isSidebarOpen ? 'ml-64' : 'ml-20'
              }`}
            >
              <div className="pt-20">{renderPage()}</div>
            </main>
          </div>
        </WatchHistoryContext.Provider>
      </MyListContext.Provider>
    </UserContext.Provider>
  );
};

export default App;
