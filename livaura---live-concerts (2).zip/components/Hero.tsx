import React, { useContext } from 'react';
import { Concert } from '../types';
import Icon from './Icon';
import { MyListContext } from '../App';

interface HeroProps {
  concert: Concert;
}

const Hero: React.FC<HeroProps> = ({ concert }) => {
  const context = useContext(MyListContext);
  if (!context) {
    throw new Error('Hero component must be used within a MyListProvider');
  }
  const { isInMyList, addToMyList, removeFromMyList } = context;

  const isBookmarked = isInMyList(concert.id);

  const handleBookmarkClick = () => {
    if (isBookmarked) {
      removeFromMyList(concert.id);
    } else {
      addToMyList(concert.id);
    }
  };
  
  return (
    <div className="relative w-full h-[60vh] text-white">
      <img
        src={concert.heroUrl}
        alt={`Hero image for ${concert.title}`}
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent"></div>
      <div className="absolute bottom-0 left-0 p-4 sm:p-8 lg:p-12 w-full md:w-1/2 lg:w-2/3">
        <h2 className="text-4xl lg:text-5xl font-extrabold drop-shadow-lg">{concert.artist}</h2>
        <h3 className="text-2xl lg:text-3xl font-bold text-gray-300 drop-shadow-lg mb-4">{concert.title}</h3>
        <p className="text-gray-200 mb-6 drop-shadow-lg hidden md:block">{concert.description}</p>
        <div className="flex items-center space-x-4">
          <button 
            data-ignore-outside-click="true"
            className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-full flex items-center transition-transform transform hover:scale-105"
          >
            <Icon path="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" className="h-6 w-6 mr-2" />
            <span>Play</span>
          </button>
          <button 
            onClick={handleBookmarkClick}
            className="bg-gray-700/50 hover:bg-gray-600/70 backdrop-blur-sm text-white font-bold py-3 px-8 rounded-full flex items-center transition-transform transform hover:scale-105"
          >
            <Icon path={isBookmarked ? "M5 13l4 4L19 7" : "M12 4v16m8-8H4"} className="h-6 w-6 mr-2" />
            <span>{isBookmarked ? 'In My List' : 'My List'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;