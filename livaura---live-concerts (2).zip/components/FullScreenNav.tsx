import React from 'react';
import Icon from './Icon';
import { SIDEBAR_ICONS } from '../constants';

interface FullScreenNavProps {
  toggleSidebar: () => void;
}

const FullScreenNav: React.FC<FullScreenNavProps> = ({ toggleSidebar }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 backdrop-blur-lg z-50 flex flex-col items-center justify-center p-8">
      <button
        onClick={toggleSidebar}
        className="absolute top-6 right-6 p-2 text-gray-400 hover:text-white transition-colors"
        aria-label="Close navigation"
      >
        <Icon path="M6 18L18 6M6 6l12 12" className="h-10 w-10" />
      </button>

      <nav className="flex flex-col items-center space-y-8">
        {SIDEBAR_ICONS.map((item) => (
          <a
            key={item.name}
            href="#"
            className="text-4xl text-gray-400 hover:text-white transition-colors font-semibold tracking-wider hover:scale-105 transform duration-200"
          >
            {item.name}
          </a>
        ))}
         <a
          href="#"
          className="text-4xl text-gray-400 hover:text-white transition-colors font-semibold tracking-wider hover:scale-105 transform duration-200"
        >
          My List
        </a>
      </nav>
    </div>
  );
};

export default FullScreenNav;
