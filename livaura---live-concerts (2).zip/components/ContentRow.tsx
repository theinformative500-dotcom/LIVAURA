import React from 'react';
import { Concert } from '../types';
import Thumbnail from './Thumbnail';

interface ContentRowProps {
  title: string;
  concerts: Concert[];
  showRank?: boolean;
}

const ContentRow: React.FC<ContentRowProps> = ({ title, concerts, showRank = false }) => {
  return (
    <div className="mb-12">
      <h2 className="text-2xl font-bold mb-6 text-white whitespace-nowrap">{title}</h2>
      <div className="flex overflow-x-auto space-x-6 pb-4 no-scrollbar">
        {concerts.map((concert, index) => (
          <div key={concert.id} className="group flex flex-col items-center text-center flex-shrink-0 w-40 sm:w-48">
            <Thumbnail concert={concert} />
            <h3 className="text-white font-normal text-sm mt-3 w-full truncate">
              {showRank && `${index + 1}. `}{concert.artist}
            </h3>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ContentRow;