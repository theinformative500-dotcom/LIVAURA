import React, { useContext } from 'react';
import { Concert } from '../types';
import { MyListContext } from '../App';
import Icon from './Icon';

interface ThumbnailProps {
  concert: Concert;
}

const Thumbnail: React.FC<ThumbnailProps> = ({ concert }) => {
  const context = useContext(MyListContext);
  if (!context) return null;
  const { isInMyList, addToMyList, removeFromMyList } = context;

  const isBookmarked = isInMyList(concert.id);

  const handleBookmarkClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isBookmarked) {
      removeFromMyList(concert.id);
    } else {
      addToMyList(concert.id);
    }
  };

  return (
    <div 
      data-ignore-outside-click="true"
      className="relative w-40 h-40 sm:w-48 sm:h-48 flex-shrink-0 rounded-full overflow-hidden cursor-pointer transition-all duration-300 ease-in-out transform group-hover:scale-105 group-hover:shadow-2xl group-hover:shadow-red-600/30"
    >
      <img src={concert.imageUrl} alt={concert.title} className="w-full h-full object-cover" loading="lazy" />
      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center p-2">
        <Icon path="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" className="h-10 w-10 text-white"/>
      </div>
      <button
        onClick={handleBookmarkClick}
        aria-label={isBookmarked ? 'Remove from My List' : 'Add to My List'}
        className="absolute top-2 right-2 z-10 p-2 bg-black/60 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-black/80 hover:scale-110"
      >
        <Icon path={isBookmarked ? 'M5 13l4 4L19 7' : 'M12 4v16m8-8H4'} className="h-5 w-5 text-white" />
      </button>
    </div>
  );
};

export default Thumbnail;