import React, { useState, useRef, useEffect, useContext } from 'react';
import Icon from './Icon';
import ProfileDropdown from './ProfileDropdown';
import NotificationsDropdown from './NotificationsDropdown';
import { Notification } from '../types';
import { UserContext } from '../App';

interface HeaderProps {
  isOpen: boolean;
  onSearchClick: () => void;
  showBackButton?: boolean;
  onBackClick?: () => void;
  onHomeClick?: () => void;
  navigateTo: (page: string) => void;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  { id: 'n1', type: 'new_release', message: 'New concert "Live at the Acropolis" was just added.', artist: 'Yanni', timestamp: '2h ago', read: false },
  { id: 'n2', type: 'recommendation', message: 'You might like "Alive 2007".', artist: 'Daft Punk', timestamp: '8h ago', read: false },
  { id: 'n3', type: 'live_event', message: 'is going live in 15 minutes!', artist: 'Odesza', timestamp: '1d ago', read: true },
  { id: 'n4', type: 'new_release', message: 'New concert "Homecoming" is now available.', artist: 'Beyoncé', timestamp: '3d ago', read: true },
];


const Header: React.FC<HeaderProps> = ({ isOpen, onSearchClick, showBackButton, onBackClick, onHomeClick, navigateTo }) => {
  const [isProfileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [isNotificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>(MOCK_NOTIFICATIONS);
  
  const userContext = useContext(UserContext);
  if (!userContext) {
    throw new Error('Header must be used within a UserProvider');
  }
  const { profileImage } = userContext;

  const profileDropdownRef = useRef<HTMLDivElement>(null);
  const profileButtonRef = useRef<HTMLButtonElement>(null);
  const notificationsDropdownRef = useRef<HTMLDivElement>(null);
  const notificationButtonRef = useRef<HTMLButtonElement>(null);
  
  const unreadCount = notifications.filter(n => !n.read).length;

  const toggleProfileDropdown = () => {
    setProfileDropdownOpen(prev => !prev);
    if (!isProfileDropdownOpen) setNotificationsOpen(false);
  };

  const toggleNotifications = () => {
    setNotificationsOpen(prev => !prev);
    if (!isNotificationsOpen) setProfileDropdownOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        profileDropdownRef.current &&
        !profileDropdownRef.current.contains(event.target as Node) &&
        profileButtonRef.current &&
        !profileButtonRef.current.contains(event.target as Node)
      ) {
        setProfileDropdownOpen(false);
      }
      if (
        notificationsDropdownRef.current &&
        !notificationsDropdownRef.current.contains(event.target as Node) &&
        notificationButtonRef.current &&
        !notificationButtonRef.current.contains(event.target as Node)
      ) {
        setNotificationsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);


  return (
    <header
      className={`fixed top-0 right-0 h-20 bg-gradient-to-b from-black to-transparent flex items-center justify-between px-4 sm:px-8 lg:px-12 z-40 transition-all duration-300 ${
        isOpen ? 'left-20 lg:left-64' : 'left-20'
      }`}
    >
      <div className="flex items-center">
        {showBackButton ? (
          <button
            onClick={onBackClick}
            className="p-2 rounded-full hover:bg-gray-800/50 transition-colors mr-4"
            aria-label="Go back"
          >
            <Icon path="M10 19l-7-7m0 0l7-7m-7 7h18" className="h-6 w-6 text-gray-300" />
          </button>
        ) : (
          <div 
            className="text-white text-xl sm:text-2xl font-black tracking-wider mr-6 cursor-pointer transition-all duration-300 hover:text-red-500 hover:drop-shadow-[0_0_8px_rgba(239,68,68,0.6)]"
            onClick={onHomeClick}
          >
            LIVAURA
          </div>
        )}
        
        <div className="relative w-full max-w-lg cursor-pointer" onClick={onSearchClick}>
          <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Icon path="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" className="h-5 w-5 text-gray-400" />
              </div>
              <div
                  className="w-full bg-black/50 border border-gray-800 text-gray-400 rounded-full py-2.5 pl-11 pr-10 transition-colors"
              >
                Search artists, concerts...
              </div>
          </div>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <div className="relative">
          <button 
            ref={notificationButtonRef}
            onClick={toggleNotifications}
            className="relative p-2 rounded-full hover:bg-gray-800/50 transition-colors" 
            aria-label={`Notifications (${unreadCount} unread)`}
            aria-haspopup="true"
            aria-expanded={isNotificationsOpen}
          >
            <Icon path="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" className="h-6 w-6 text-gray-300" />
            {unreadCount > 0 && (
              <span className="absolute top-2 right-2 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
            )}
          </button>
          <NotificationsDropdown
            ref={notificationsDropdownRef}
            isOpen={isNotificationsOpen}
            onClose={() => setNotificationsOpen(false)}
            notifications={notifications}
            setNotifications={setNotifications}
          />
        </div>
        <div className="relative">
          <button 
            ref={profileButtonRef}
            className="w-9 h-9 rounded-full bg-teal-500 overflow-hidden" 
            aria-label="User Profile"
            onClick={toggleProfileDropdown}
            aria-haspopup="true"
            aria-expanded={isProfileDropdownOpen}
          >
             <img src={profileImage} alt="User Profile" className="w-full h-full object-cover" />
          </button>
          <ProfileDropdown 
            ref={profileDropdownRef}
            isOpen={isProfileDropdownOpen}
            onClose={() => setProfileDropdownOpen(false)}
            navigateTo={navigateTo}
          />
        </div>
      </div>
    </header>
  );
};

export default Header;