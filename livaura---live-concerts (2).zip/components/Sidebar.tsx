import React, { useState, forwardRef } from 'react';
import Icon from './Icon';
import { SIDEBAR_ICONS } from '../constants';

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
  navigateTo: (page: string) => void;
}

const Sidebar = forwardRef<HTMLElement, SidebarProps>(({ isOpen, toggleSidebar, navigateTo }, ref) => {
  const [activeIcon, setActiveIcon] = useState('Home');

  const handleNav = (name: string, page: string) => {
    setActiveIcon(name);
    navigateTo(page);
  };

  const navItemClasses = (name: string) => `
    flex items-center w-full p-2 rounded-lg
    transition-colors duration-200 
    ${isOpen ? 'justify-start space-x-4' : 'justify-center'}
    ${activeIcon === name ? 'bg-gray-800' : 'hover:bg-gray-800/50'}
  `;

  const iconClasses = (name: string) => `
    h-7 w-7 transition-colors duration-200 flex-shrink-0
    ${activeIcon === name ? 'text-white' : 'text-gray-400 group-hover:text-white'}
  `;

  return (
    <aside
      ref={ref}
      className={`fixed top-0 left-0 h-full bg-black bg-opacity-80 backdrop-blur-md flex flex-col py-6 z-50 transition-all duration-300 ${
        isOpen ? 'w-64 items-start px-4' : 'w-20 items-center px-2'
      }`}
    >
      <div className={`${isOpen ? 'self-start' : 'self-center'}`}>
        <button className="p-2" aria-label="Toggle sidebar" onClick={toggleSidebar}>
          <Icon path="M4 6h16M4 12h16M4 18h16" className="h-8 w-8 text-gray-400 hover:text-white transition-colors duration-200" />
        </button>
      </div>

      <nav className="flex flex-col w-full space-y-6 mt-16">
        {SIDEBAR_ICONS.map((item) => (
          <div key={item.name} className="relative w-full group">
            <button className={navItemClasses(item.name)} onClick={() => handleNav(item.name, item.page)} aria-label={item.name} aria-current={activeIcon === item.name ? 'page' : undefined}>
              <Icon path={item.icon} className={iconClasses(item.name)} />
              {isOpen && <span className={`transition-colors duration-200 ${activeIcon === item.name ? 'text-white' : 'text-gray-400 group-hover:text-white'}`}>{item.name}</span>}
            </button>
            {!isOpen && (
              <div className="absolute left-full ml-4 top-1/2 -translate-y-1/2 z-20 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <div className="bg-gray-800 text-white text-sm rounded py-1 px-3 whitespace-nowrap">
                  {item.name}
                </div>
              </div>
            )}
            <div className={`absolute bottom-[-4px] h-1 bg-red-600 rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-200 ease-in-out ${
                isOpen ? 'left-2 w-5' : 'left-1/2 -translate-x-1/2 w-5'
              }`}></div>
          </div>
        ))}
      </nav>

      <div className="mt-auto w-full">
        <div className="relative w-full group">
            <button className={navItemClasses('My List')} onClick={() => handleNav('My List', 'mylist')} aria-label="My List" aria-current={activeIcon === 'My List' ? 'page' : undefined}>
                <Icon path="M12 4v16m8-8H4" className={iconClasses('My List')} />
                {isOpen && <span className={`transition-colors duration-200 ${activeIcon === 'My List' ? 'text-white' : 'text-gray-400 group-hover:text-white'}`}>My List</span>}
            </button>
             {!isOpen && (
              <div className="absolute left-full ml-4 top-1/2 -translate-y-1/2 z-20 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <div className="bg-gray-800 text-white text-sm rounded py-1 px-3 whitespace-nowrap">
                  My List
                </div>
              </div>
            )}
            <div className={`absolute bottom-[-4px] h-1 bg-red-600 rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-200 ease-in-out ${
                isOpen ? 'left-2 w-5' : 'left-1/2 -translate-x-1/2 w-5'
              }`}></div>
        </div>
      </div>
    </aside>
  );
});

export default Sidebar;