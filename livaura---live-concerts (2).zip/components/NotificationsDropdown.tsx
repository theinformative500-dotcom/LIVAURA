import React, { forwardRef } from 'react';
import Icon from './Icon';
import { Notification } from '../types';

interface NotificationsDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: Notification[];
  setNotifications: React.Dispatch<React.SetStateAction<Notification[]>>;
}

const NotificationIcon: React.FC<{ type: Notification['type'] }> = ({ type }) => {
  const iconMap = {
    new_release: 'M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 6l12-3',
    recommendation: 'M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z',
    live_event: 'M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.636 5.636a9 9 0 0112.728 0M8.464 15.536a5 5 0 01-7.072 0'
  };
  return <Icon path={iconMap[type]} className="h-6 w-6 text-gray-400 flex-shrink-0" />;
};


const NotificationsDropdown = forwardRef<HTMLDivElement, NotificationsDropdownProps>(({ isOpen, onClose, notifications, setNotifications }, ref) => {
  if (!isOpen) return null;

  const handleClearAll = () => {
    setNotifications([]);
    onClose();
  };

  const handleMarkAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };
  
  const hasNotifications = notifications.length > 0;
  const hasUnread = notifications.some(n => !n.read);

  return (
    <div
      ref={ref}
      className="absolute top-16 right-0 w-80 max-h-[80vh] flex flex-col bg-gray-900/80 backdrop-blur-md border border-gray-700 rounded-lg shadow-lg z-50 animate-fade-in"
    >
      <div className="p-4 border-b border-gray-700 flex justify-between items-center">
        <h3 className="font-bold text-white">Notifications</h3>
        {hasNotifications && (
            <button 
                onClick={handleClearAll}
                className="text-sm text-red-400 hover:text-red-300 transition-colors"
            >
                Clear All
            </button>
        )}
      </div>

      {hasNotifications ? (
        <div className="overflow-y-auto no-scrollbar">
            {notifications.map(notification => (
                <div 
                    key={notification.id} 
                    className={`flex items-start space-x-4 p-4 border-b border-gray-800/50 transition-colors ${!notification.read ? 'bg-gray-800/40' : 'hover:bg-gray-700/50'}`}
                >
                    <NotificationIcon type={notification.type} />
                    <div className="flex-1">
                        <p className="text-sm text-white">
                           <span className="font-bold">{notification.artist}</span> {notification.message}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">{notification.timestamp}</p>
                    </div>
                    {!notification.read && (
                        <button 
                            onClick={() => handleMarkAsRead(notification.id)}
                            aria-label="Mark as read"
                            className="w-3 h-3 rounded-full bg-red-500 mt-1 flex-shrink-0 hover:bg-red-400 transition-colors" 
                        />
                    )}
                </div>
            ))}
        </div>
      ) : (
         <div className="p-8 text-center">
            <Icon path="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-5-5.917V5a2 2 0 10-4 0v.083A6.002 6.002 0 004 11v3.159c0 .538-.214 1.055-.595 1.436L2 17h13z" className="h-12 w-12 text-gray-600 mx-auto mb-4" />
            <p className="text-sm text-gray-400">You're all caught up!</p>
        </div>
      )}
    </div>
  );
});

export default NotificationsDropdown;